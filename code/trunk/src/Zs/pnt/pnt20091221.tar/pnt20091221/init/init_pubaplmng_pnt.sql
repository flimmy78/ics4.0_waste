delete from pubaplmng where BrNo='484999' and AplCls='215';
insert into pubaplmng values( '484999', '215', 'PNT01', '', '9999999999' );
