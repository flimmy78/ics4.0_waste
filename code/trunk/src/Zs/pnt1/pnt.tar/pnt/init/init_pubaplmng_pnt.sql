delete from pubaplmng where BrNo='XXXXXX' and AplCls='215';
insert into pubaplmng values( 'XXXXXX', '215', 'PNT01', '', '9999999999' );
